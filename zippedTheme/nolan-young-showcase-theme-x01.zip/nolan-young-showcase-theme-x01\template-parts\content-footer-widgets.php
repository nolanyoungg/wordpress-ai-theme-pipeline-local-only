﻿







<?php








/**








 * Template part for displaying the footer widgets.








 *








 * @package Nolan_Young_Showcase_Theme_X01








 */

















if ( ! is_active_sidebar( 'footer-1' ) && ! is_active_sidebar( 'footer-2' ) && ! is_active_sidebar( 'footer-3' ) ) {








	return;








}








?>

















<footer class="site-footer">








	<div class="container">








		<?php if ( is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) ) : ?>








			<div class="footer-widgets">








				<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>








					<div class="footer-widget-area">








						<?php dynamic_sidebar( 'footer-1' ); ?>








					</div>








				<?php endif; ?>

















				<?php if ( is_active_sidebar( 'footer-2' ) ) : ?>








					<div class="footer-widget-area">








						<?php dynamic_sidebar( 'footer-2' ); ?>








					</div>








				<?php endif; ?>

















				<?php if ( is_active_sidebar( 'footer-3' ) ) : ?>








					<div class="footer-widget-area">








						<?php dynamic_sidebar( 'footer-3' ); ?>








					</div>








				<?php endif; ?>








			</div><!-- .footer-widgets -->








		<?php endif; ?>

















		<div class="site-info">








			<p>&copy; <?php echo esc_html( date_i18n( __( 'Y', 'nolan-young-showcase-theme-x01' ) ) ); ?> <?php bloginfo( 'name' ); ?>. <?php esc_html_e( 'All rights reserved.', 'nolan-young-showcase-theme-x01' ); ?></p>








			<p><?php esc_html_e( 'Privacy Policy', 'nolan-young-showcase-theme-x01' ); ?> | <?php esc_html_e( 'Terms of Service', 'nolan-young-showcase-theme-x01' ); ?></p>








		</div><!-- .site-info -->








	</div><!-- .container -->








</footer><!-- .site-footer -->









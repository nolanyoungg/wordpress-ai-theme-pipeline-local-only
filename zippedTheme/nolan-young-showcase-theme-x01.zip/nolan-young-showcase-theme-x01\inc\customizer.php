﻿







<?php








/**








 * Customizer additions for the theme.








 *








 * @package Nolan_Young_Showcase_Theme_X01








 */

















if ( ! defined( 'ABSPATH' ) ) {








	exit; // Exit if accessed directly.








}

















/**








 * Add postMessage support for site title and description for the Theme Customizer.








 *








 * @param WP_Customize_Manager $wp_customize Theme Customizer object.








 */








function nolan_young_showcase_theme_x01_customize_register( $wp_customize ) {








	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';








	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';








	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

















	if ( isset( $wp_customize->selective_refresh ) ) {








		$wp_customize->selective_refresh->add_partial(








			'blogname',








			array(








				'selector'        => '.site-title a',








				'render_callback' => 'nolan_young_showcase_theme_x01_customize_partial_blogname',








			)








		);








		$wp_customize->selective_refresh->add_partial(








			'blogdescription',








			array(








				'selector'        => '.site-description',








				'render_callback' => 'nolan_young_showcase_theme_x01_customize_partial_blogdescription',








			)








		);








	}








}

















/**








 * Render the site title for the selective refresh partial.








 *








 * @return void








 */








function nolan_young_showcase_theme_x01_customize_partial_blogname() {








	bloginfo( 'name' );








}

















/**








 * Render the site tagline for the selective refresh partial.








 *








 * @return void








 */








function nolan_young_showcase_theme_x01_customize_partial_blogdescription() {








	bloginfo( 'description' );








}

















/**








 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.








 */








function nolan_young_showcase_theme_x01_customize_preview_js() {








	wp_enqueue_script( 'nolan-young-showcase-theme-x01-customizer', get_template_directory_uri() . '/assets/js/customizer.js', array( 'customize-preview' ), '20151215', true );








}

















add_action( 'customize_register', 'nolan_young_showcase_theme_x01_customize_register' );








add_action( 'customize_preview_init', 'nolan_young_showcase_theme_x01_customize_preview_js' );









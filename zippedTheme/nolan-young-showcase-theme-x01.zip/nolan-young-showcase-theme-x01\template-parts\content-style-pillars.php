﻿







```php








<?php








/**








 * Template part for displaying the signature style / style pillars section on the homepage.








 *








 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/








 *








 * @package Nolan_Young_Showcase_Theme_X01








 */

















?>

















<section class="section-style-pillars">








    <div class="container">








        <h2 class="section-title">Signature Style / Style Pillars</h2>








        <p class="section-description">Our approach to photography is guided by these core principles:</p>

















        <div class="style-pillars-grid">








            <?php








            $pillars = [








                'Light' => 'We capture the essence of light, ensuring every moment is illuminated.',








                'Direction' => 'Our creative direction is clear and intentional, guiding each session.',








                'Composition' => 'Each frame is carefully composed to tell a story.',








                'Editing' => 'Warm, polished edits without overprocessing.',








                'Delivery' => 'From inquiry to gallery delivery, we provide a seamless experience.',








            ];

















            foreach ($pillars as $title => $description) {








                echo '<div class="style-pillar">';








                echo '<h3>' . esc_html($title) . '</h3>';








                echo '<p>' . esc_html($description) . '</p>';








                echo '</div>';








            }








            ?>








        </div>








    </div>








</section>















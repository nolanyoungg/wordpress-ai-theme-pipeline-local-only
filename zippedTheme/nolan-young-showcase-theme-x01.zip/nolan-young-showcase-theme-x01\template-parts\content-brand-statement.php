﻿







```php








<?php








/**








 * Template part for displaying the brand statement section on the homepage.








 *








 * @package Nolan_Young_Showcase_Theme_X01








 */

















?>

















<section class="brand-statement">








    <div class="container">








        <h2 class="section-title">Our Studio Philosophy</h2>








        <p>At MNY Photo, we believe in capturing the essence of every moment with warmth and precision. Our approach is guided by a deep understanding of your vision, ensuring that each photograph tells a unique story. We are dedicated to delivering high-end imagery that elevates your brand and leaves a lasting impression.</p>








        <a href="/who-we-are/" class="btn btn-primary">Learn More About Us</a>








    </div>








</section>















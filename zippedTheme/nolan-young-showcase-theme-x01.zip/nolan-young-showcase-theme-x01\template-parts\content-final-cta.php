﻿







```php








<?php








/**








 * Template part for displaying the final CTA section on the homepage.








 *








 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/








 *








 * @package Nolan_Young_Showcase_Theme_X01








 */

















?>

















<section class="final-cta">








    <div class="container">








        <h2><?php esc_html_e( 'Ready to Capture Your Story?', 'nolan-young-showcase-theme-x01' ); ?></h2>








        <p><?php esc_html_e( 'Let\'s work together to create stunning visuals that tell your unique story.', 'nolan-young-showcase-theme-x01' ); ?></p>








        <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn btn-primary"><?php esc_html_e( 'Contact Us', 'nolan-young-showcase-theme-x01' ); ?></a>








    </div>








</section>














